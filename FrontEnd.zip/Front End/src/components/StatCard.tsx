import React from 'react';

interface StatCardProps {
  title: string;
  value: string | number;
  description?: string;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, description }) => {
  return (
    <div 
      className="bg-[rgba(18,22,37,0.63)] p-8 rounded-xl text-center border border-[#4dfaf61f] 
               shadow-[0_2px_28px_rgba(0,255,238,0.2)] transition-all duration-300 
               hover:shadow-[0_8px_34px_rgba(0,255,224,0.48)] hover:border-[#30ffeeaa]"
    >
      <h3 className="font-syncopate text-[#20fcd7] text-4xl md:text-5xl">{value}</h3>
      <p className="text-[#c1fcfc] uppercase tracking-wider mt-2">{title}</p>
      {description && (
        <p className="text-[#87ffffbb] text-sm mt-2">{description}</p>
      )}
    </div>
  );
};

export default StatCard;