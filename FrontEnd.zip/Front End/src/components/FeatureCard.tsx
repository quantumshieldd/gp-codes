import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon: Icon, title, description }) => {
  return (
    <div 
      className="bg-[rgba(24,28,43,0.93)] p-6 rounded-xl border border-[rgba(62,255,210,0.13)] 
                flex items-start gap-4 shadow-[0_2px_18px_rgba(17,255,249,0.13)] 
                transition-all duration-300 hover:shadow-[0_4px_24px_rgba(17,255,249,0.28)] 
                hover:border-[rgba(62,255,210,0.25)]"
    >
      <div className="text-[#2effe1] p-2 rounded-lg bg-[rgba(46,255,225,0.07)]">
        <Icon size={24} strokeWidth={2} />
      </div>
      <div>
        <h3 className="m-0 text-[#00ebcf] font-semibold text-lg">{title}</h3>
        <p className="mt-1 text-[#7bfcee] text-sm">{description}</p>
      </div>
    </div>
  );
};

export default FeatureCard;