import React, { useEffect, useRef } from 'react';
import StatCard from './StatCard';
import { useImageProcessing } from '../context/ImageProcessingContext';

const StatsSection: React.FC = () => {
  const { stats } = useImageProcessing();
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.13 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  const cleanCount = stats.totalImages - stats.attacksDetected;

  return (
    <section ref={sectionRef} className="py-20 fade-in" id="summary">
      <div className="container mx-auto px-4">
        <h2 className="font-syncopate text-3xl md:text-4xl text-[#7dffe6] mb-12 cyberpunk-border gradient-text inline-block">
          Report Summary
        </h2>
        <div className="bg-[rgba(26,28,38,0.95)] p-8 md:p-12 rounded-3xl shadow-[0_0_44px_rgba(41,255,231,0.15)] backdrop-blur-md">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <StatCard
              title="Total Images"
              value={Math.floor(stats.totalImages / 2)}

              description="Images analyzed through our platform"
            />
            <StatCard
              title="Attacks Detected"
              value={Math.floor(stats.attacksDetected / 2)}

              description="Successfully identified adversarial samples"
            />
            <StatCard
              title="Clean"
              value={Math.floor(cleanCount / 2)}

              description="Images classified as safe"
            />
            <StatCard
              title="Model Accuracy"
              value={`${stats.accuracy}%`}
              description="On real-world test datasets"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default StatsSection;
