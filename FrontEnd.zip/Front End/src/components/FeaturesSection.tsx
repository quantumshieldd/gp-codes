import React, { useEffect, useRef } from 'react';
import { Search, Shield, Star, CheckSquare } from 'lucide-react';
import FeatureCard from './FeatureCard';

const FeaturesSection: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.13 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <section ref={sectionRef} className="py-20 fade-in" id="how-it-works">
      <div className="container mx-auto px-4">
        <h2 className="font-syncopate text-3xl md:text-4xl text-[#7dffe6] mb-12 cyberpunk-border gradient-text inline-block">
          How It Works
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <FeatureCard 
            icon={Search}
            title="Image Checked"
            description="Quick cleanup & normalization before processing"
          />
          <FeatureCard 
            icon={Shield}
            title="CNN + Quantum"
            description="Classic & quantum fusion algorithms for detection"
          />
          <FeatureCard 
            icon={Star}
            title="Results Out"
            description="Clean or Attacked? Discover instantly with high confidence"
          />
          <FeatureCard 
            icon={CheckSquare}
            title="91% Accuracy"
            description="On real-world and simulated attack images"
          />
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;