import { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-[#13132399] backdrop-blur-lg border-b border-[#50ffef12] shadow-[0_2px_24px_rgba(30,255,255,0.12)]' 
          : 'bg-transparent'
      }`}
    >
      <div className="w-full px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16 md:h-20">
          <NavLink
            to="/"
            className="font-syncopate text-[#44fff7] text-xl md:text-2xl font-bold tracking-tighter text-glow transition-all duration-300 hover:text-glow-strong"
          >
            Quantum Shield
          </NavLink>
          
          {/* Mobile menu button */}
          <div className="flex md:hidden">
            <button
              onClick={toggleMenu}
              className="text-[#44fff7] hover:text-[#7bfffa] transition-colors"
              aria-expanded={isMenuOpen}
              aria-label="Toggle navigation menu"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
          
          {/* Desktop menu */}
          <div className="hidden md:flex">
            <ul className="flex space-x-8 lg:space-x-12">
              <li>
                <NavLink
                  to="/"
                  className={({ isActive }) => 
                    `uppercase font-semibold tracking-wide text-sm py-1.5 border-b-2 transition-all ${
                      isActive 
                        ? 'text-[#43fff0] border-[#43fff0]' 
                        : 'text-white border-transparent hover:text-[#43fff0] hover:border-[#43fff0]'
                    }`
                  }
                >
                  Home
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/dashboard"
                  className={({ isActive }) => 
                    `uppercase font-semibold tracking-wide text-sm py-1.5 border-b-2 transition-all ${
                      isActive 
                        ? 'text-[#43fff0] border-[#43fff0]' 
                        : 'text-white border-transparent hover:text-[#43fff0] hover:border-[#43fff0]'
                    }`
                  }
                >
                  Dashboard
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/report"
                  className={({ isActive }) => 
                    `uppercase font-semibold tracking-wide text-sm py-1.5 border-b-2 transition-all ${
                      isActive 
                        ? 'text-[#43fff0] border-[#43fff0]' 
                        : 'text-white border-transparent hover:text-[#43fff0] hover:border-[#43fff0]'
                    }`
                  }
                >
                  Report
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/about"
                  className={({ isActive }) => 
                    `uppercase font-semibold tracking-wide text-sm py-1.5 border-b-2 transition-all ${
                      isActive 
                        ? 'text-[#43fff0] border-[#43fff0]' 
                        : 'text-white border-transparent hover:text-[#43fff0] hover:border-[#43fff0]'
                    }`
                  }
                >
                  About
                </NavLink>
              </li>
            </ul>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-[#171728f5] backdrop-blur-xl shadow-lg">
          <div className="px-2 pt-2 pb-4 space-y-1 sm:px-3 border-t border-[#50ffef1a]">
            <NavLink
              to="/"
              onClick={() => setIsMenuOpen(false)}
              className={({ isActive }) => 
                `block py-3 px-3 text-base uppercase font-semibold tracking-wide rounded-md ${
                  isActive 
                    ? 'text-[#43fff0] bg-[#43fff015]' 
                    : 'text-gray-100 hover:text-[#43fff0] hover:bg-[#43fff00d]'
                }`
              }
            >
              Home
            </NavLink>
            <NavLink
              to="/dashboard"
              onClick={() => setIsMenuOpen(false)}
              className={({ isActive }) => 
                `block py-3 px-3 text-base uppercase font-semibold tracking-wide rounded-md ${
                  isActive 
                    ? 'text-[#43fff0] bg-[#43fff015]' 
                    : 'text-gray-100 hover:text-[#43fff0] hover:bg-[#43fff00d]'
                }`
              }
            >
              Dashboard
            </NavLink>
            <NavLink
              to="/report"
              onClick={() => setIsMenuOpen(false)}
              className={({ isActive }) => 
                `block py-3 px-3 text-base uppercase font-semibold tracking-wide rounded-md ${
                  isActive 
                    ? 'text-[#43fff0] bg-[#43fff015]' 
                    : 'text-gray-100 hover:text-[#43fff0] hover:bg-[#43fff00d]'
                }`
              }
            >
              Report
            </NavLink>
            <NavLink
              to="/about"
              onClick={() => setIsMenuOpen(false)}
              className={({ isActive }) => 
                `block py-3 px-3 text-base uppercase font-semibold tracking-wide rounded-md ${
                  isActive 
                    ? 'text-[#43fff0] bg-[#43fff015]' 
                    : 'text-gray-100 hover:text-[#43fff0] hover:bg-[#43fff00d]'
                }`
              }
            >
              About
            </NavLink>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;