import React, { useState, useRef, useCallback } from 'react';
import { Upload, X, Image, Loader2 } from 'lucide-react';
import { useImageProcessing } from '../context/ImageProcessingContext';
import { analyzeImage } from '../api/analyzeImage';

const ImageUploader: React.FC = () => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  const {
    addDetectionResult,
    updateStats,
    setProcessingStatus,
    processingStatus,
    clearResults
  } = useImageProcessing();

  const [selectedImages, setSelectedImages] = useState<Array<{ file: File, url: string }>>([]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      handleFiles(Array.from(event.target.files));
    }
  };

  const handleFiles = useCallback((files: File[]) => {
    const validFiles = files.filter(file =>
      file.type === 'image/png' ||
      file.type === 'image/jpeg' ||
      file.type === 'image/jpg' ||
      file.type === 'image/webp'
    );

    const newImages = validFiles.map(file => ({
      file,
      url: URL.createObjectURL(file)
    }));

    setSelectedImages(newImages);
  }, []);

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files) {
      handleFiles(Array.from(e.dataTransfer.files));
    }
  };

  const removePreview = (index: number) => {
    setSelectedImages(prev => {
      const newImages = [...prev];
      URL.revokeObjectURL(newImages[index].url);
      newImages.splice(index, 1);
      return newImages;
    });
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const handleAnalyze = async () => {
    if (selectedImages.length === 0) return;

    setProcessingStatus('processing');

    for (const image of selectedImages) {
      try {
        const result = await analyzeImage(image.file);

        const detection = {
          id: `result-${Date.now()}`,
          filename: image.file.name,
          imageUrl: image.url,
          status: result.prediction.toLowerCase() === 'adversarial' ? 'attacked' : 'clean',
          confidence: parseFloat((result.confidence * 100).toFixed(1))
        };

        addDetectionResult(detection);
        updateStats(detection.status);

      } catch (error) {
        console.error("Prediction failed for image:", image.file.name, error);
      }
    }

    setProcessingStatus('completed');
    setTimeout(() => {
      resultRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 200);
  };

  const handleClear = () => {
    selectedImages.forEach(img => URL.revokeObjectURL(img.url));
    setSelectedImages([]);
    clearResults();
  };

  return (
    <div className="w-full">
      <div
        className={`mt-6 border-2 border-dashed rounded-2xl p-8 text-center transition-all duration-300
        ${isDragging ? 'border-[#28fffac8] bg-[#21293644]' : 'border-[#32ffe0aa] bg-[rgba(255,255,255,0.05)]'}
        ${processingStatus === 'processing' ? 'opacity-60 pointer-events-none' : ''}`}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        onClick={triggerFileInput}
      >
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          accept=".png,.jpg,.jpeg,.webp"
          multiple
          onChange={handleFileChange}
          disabled={processingStatus === 'processing'}
        />
        <div className="flex flex-col items-center justify-center py-6">
          <Upload className="h-12 w-12 text-[#43fff0] mb-4" />
          <h3 className="text-xl font-semibold text-[#cafcff] mb-2">
            Drag and drop image files here
          </h3>
          <p className="text-[#94f1f1] mb-4">or click to select files</p>
          <p className="text-[#76c1be] text-sm">Supported formats: PNG, JPG, JPEG, WebP</p>
        </div>
      </div>

      {selectedImages.length > 0 && (
        <div className="mt-6" ref={resultRef}>
          <h3 className="text-lg font-semibold text-[#cafcff] mb-4">Selected Images:</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {selectedImages.map((image, index) => (
              <div key={index} className="relative group">
                <div className="aspect-square rounded-lg overflow-hidden border border-[#44fff730] bg-[#161622]">
                  <img src={image.url} alt={`Preview ${index}`} className="w-full h-full object-cover" />
                </div>
                <button
                  className="absolute top-2 right-2 bg-[#0b0b14cc] p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={(e) => {
                    e.stopPropagation();
                    removePreview(index);
                  }}
                >
                  <X className="h-4 w-4 text-[#ff4e4e]" />
                </button>
                <p className="text-xs text-[#94f1f1] mt-1 truncate">{image.file.name}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {selectedImages.length === 0 && (
        <div className="mt-8 text-center">
          <div className="inline-flex items-center justify-center p-6 rounded-full bg-[rgba(46,255,225,0.07)]">
            <Image className="h-10 w-10 text-[#43fff0]" />
          </div>
          <p className="mt-4 text-[#94f1f1]">No images selected yet</p>
        </div>
      )}

      <div className="mt-8 flex justify-center gap-4">
        <button
          className={`bg-gradient-to-r from-[#31fad0] via-[#23a3fa] to-[#383872] px-8 py-4 rounded-xl
            font-semibold uppercase tracking-wider text-white transition-all duration-300
            hover:shadow-[0_7px_44px_rgba(0,255,232,0.53)] hover:translate-y-[-2px] hover:scale-105
            ${processingStatus === 'processing' || selectedImages.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
          disabled={selectedImages.length === 0 || processingStatus === 'processing'}
          onClick={handleAnalyze}
        >
          {processingStatus === 'processing' ? (
            <span className="inline-flex items-center gap-2">
              <Loader2 className="animate-spin w-5 h-5" /> Processing...
            </span>
          ) : (
            'Analyze Images'
          )}
        </button>

        <button
          onClick={handleClear}
          className="bg-[#3f121a] px-8 py-4 rounded-xl font-semibold uppercase tracking-wider text-[#ff6b6b] transition-all duration-300 hover:bg-[#5f1d2a] hover:scale-105"
        >
          Clear Results
        </button>
      </div>
    </div>
  );
};

export default ImageUploader;
