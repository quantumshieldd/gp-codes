import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#0B0B14] text-[#87ffffbb] text-center py-8 border-t border-[#1effe53d] mt-28 shadow-[0_0_40px_rgba(17,255,224,0.21)]">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div className="text-left">
            <h3 className="font-syncopate text-[#44fff7] text-lg mb-4">Quantum Shield</h3>
            <p className="text-[#87ffffbb] text-sm">
              Advanced AI-powered system for detecting & classifying adversarial attacks in autonomous vehicles.
            </p>
          </div>
          <div className="text-left">
            <h3 className="font-syncopate text-[#44fff7] text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="/" className="text-[#87ffffbb] hover:text-[#44fff7] transition-colors">Home</a></li>
              <li><a href="/dashboard" className="text-[#87ffffbb] hover:text-[#44fff7] transition-colors">Dashboard</a></li>
              <li><a href="/report" className="text-[#87ffffbb] hover:text-[#44fff7] transition-colors">Reports</a></li>
              <li><a href="/about" className="text-[#87ffffbb] hover:text-[#44fff7] transition-colors">About</a></li>
            </ul>
          </div>
          <div className="text-left">
            <h3 className="font-syncopate text-[#44fff7] text-lg mb-4">Contact</h3>
            <p className="text-[#87ffffbb] text-sm mb-2">
              Princess Sumaya University for Technology
            </p>
            <p className="text-[#87ffffbb] text-sm">
              <a href="mailto:info@quantumshield.ai" className="hover:text-[#44fff7] transition-colors">
                info@quantumshield.ai
              </a>
            </p>
          </div>
        </div>
        <div className="pt-6 border-t border-[#1effe51a]">
          &copy; {new Date().getFullYear()} Quantum Shield. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;