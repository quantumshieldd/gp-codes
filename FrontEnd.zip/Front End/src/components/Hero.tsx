import React, { useEffect, useRef } from 'react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Hero: React.FC = () => {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (heroRef.current) {
      heroRef.current.classList.add('visible');
    }
  }, []);

  return (
    <section 
      className="min-h-screen pt-20 relative hero-radial flex items-center"
      ref={heroRef}
    >
      <div className="container mx-auto px-4 py-16 md:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div className="fade-in visible">
            <h1 className="font-syncopate text-[#33ffe9] text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-glow leading-tight">
              Quantum Shield
            </h1>
            <p className="text-[#b8f3fa] text-lg md:text-xl mb-10 max-w-2xl">
              Advanced AI-powered system for detecting & classifying adversarial attacks in autonomous vehicles.
              Cutting-edge security for the future of mobility.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/dashboard"
                className="inline-flex items-center justify-center bg-gradient-to-r from-[#31fad0] via-[#23a3fa] to-[#383872] px-6 py-3 rounded-xl font-semibold tracking-wide uppercase text-white transition-all duration-300 hover:shadow-[0_7px_44px_rgba(0,255,232,0.53)] hover:translate-y-[-2px] hover:scale-105"
              >
                Upload & Analyze
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <Link
                to="/about"
                className="inline-flex items-center justify-center bg-[rgba(255,255,255,0.05)] border border-[#44fff730] px-6 py-3 rounded-xl font-semibold tracking-wide uppercase text-white transition-all duration-300 hover:bg-[rgba(255,255,255,0.1)] hover:border-[#44fff7]"
              >
                Learn More
              </Link>
            </div>
          </div>
          <div className="fade-in visible">
            <div className="relative rounded-3xl overflow-hidden shadow-[0_0_80px_rgba(30,243,255,0.2)] transition-all duration-500 hover:shadow-[0_0_100px_rgba(30,243,255,0.35)]">
              <img 
                src="/images/av.jpg" 
                alt="Autonomous Vehicle Dashboard" 
                className="w-full h-auto rounded-3xl transition-all duration-700 hover:scale-105 hover:filter hover:brightness-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b14cc] via-transparent to-transparent rounded-3xl"></div>
              <div className="absolute bottom-6 left-6 right-6">
                <div className="bg-[#161622bb] backdrop-blur-md p-4 rounded-xl border border-[#44fff730]">
                  <p className="text-[#44fff7] font-semibold font-syncopate">
                    91% Detection Accuracy
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;