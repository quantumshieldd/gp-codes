import React, { useEffect, useRef } from 'react';
import { useImageProcessing } from '../context/ImageProcessingContext';

const ResultTable: React.FC = () => {
  const { detectionResults } = useImageProcessing();
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.13 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <section ref={sectionRef} className="py-20 fade-in" id="report">
      <div className="container mx-auto px-4">
        <h2 className="font-syncopate text-3xl md:text-4xl text-[#7dffe6] mb-12 cyberpunk-border gradient-text inline-block">
          Detailed Detection Report
        </h2>
        
        <div className="overflow-x-auto">
          <table className="w-full shadow-[0_8px_38px_rgba(16,255,248,0.11)] rounded-xl overflow-hidden">
            <thead>
              <tr>
                <th className="bg-gradient-to-r from-[#23243b] to-[#191928] text-[#18ffe2] p-5 font-syncopate uppercase tracking-wider text-left">
                  Image
                </th>
                <th className="bg-gradient-to-r from-[#23243b] to-[#191928] text-[#18ffe2] p-5 font-syncopate uppercase tracking-wider text-left">
                  Preview
                </th>
                <th className="bg-gradient-to-r from-[#23243b] to-[#191928] text-[#18ffe2] p-5 font-syncopate uppercase tracking-wider text-left">
                  Status
                </th>
                <th className="bg-gradient-to-r from-[#23243b] to-[#191928] text-[#18ffe2] p-5 font-syncopate uppercase tracking-wider text-left">
                  Confidence
                </th>
              </tr>
            </thead>
            <tbody className="bg-[rgba(21,23,36,0.90)]">
              {detectionResults.length > 0 ? (
                detectionResults.map((result, index) => (
                  <tr 
                    key={index} 
                    className="border-b border-[#0bffe011] hover:bg-[#1e222e66] transition-colors"
                  >
                    <td className="p-4 text-[#cafcff]">{result.filename}</td>
                    <td className="p-4">
                      {result.imageUrl && (
                        <div className="h-16 w-16 rounded-md overflow-hidden border border-[#44fff730]">
                          <img 
                            src={result.imageUrl} 
                            alt={result.filename} 
                            className="h-full w-full object-cover"
                          />
                        </div>
                      )}
                    </td>
                    <td className="p-4">
                      <span 
                        className={`
                          font-medium text-sm uppercase tracking-wider py-1.5 px-4 rounded-full inline-block
                          ${result.status === 'attacked' 
                            ? 'text-[#ff4545] bg-[#361015aa] shadow-[0_0_17px_rgba(255,33,104,0.2)]' 
                            : 'text-[#19fd83] bg-[#173614a4] shadow-[0_0_17px_rgba(19,250,153,0.23)]'
                          }
                        `}
                      >
                        {result.status}
                      </span>
                    </td>
                    <td className="p-4 text-[#cafcff]">{result.confidence}%</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="p-8 text-center text-[#87ffffbb]">
                    No detection results yet. Upload images to see results here.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};

export default ResultTable;