import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { DetectionResult } from '../context/ImageProcessingContext';

export const generatePDFReport = (results: DetectionResult[]) => {
  const doc = new jsPDF();

  doc.setFillColor(18, 20, 33);
  doc.rect(0, 0, 210, 297, 'F');

  doc.setTextColor(125, 255, 230);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.text('Quantum Shield - Detection Report', 105, 20, { align: 'center' });

  const tableData = results.map((r) => [
    r.filename,
    r.status.toUpperCase(),
    `${r.confidence.toFixed(1)}%`,
  ]);

  autoTable(doc, {
    startY: 30,
    head: [['Filename', 'Status', 'Confidence']],
    body: tableData,
    styles: {
      fillColor: [33, 40, 53],
      textColor: [200, 255, 255],
    },
    headStyles: {
      fillColor: [67, 255, 240],
      textColor: [0, 0, 0],
      fontStyle: 'bold',
    },
    margin: { top: 30 },
  });

  doc.save('quantum_shield_report.pdf');
};
