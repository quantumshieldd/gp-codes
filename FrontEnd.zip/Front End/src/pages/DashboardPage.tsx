import React, { useEffect } from 'react';
import ImageUploader from '../components/ImageUploader';
import { useImageProcessing } from '../context/ImageProcessingContext';
import { Trash2, BarChart3, AlertCircle, CheckCircle } from 'lucide-react';

const DashboardPage: React.FC = () => {
  const { detectionResults, stats, clearResults } = useImageProcessing();
  
  useEffect(() => {
    document.title = 'Dashboard - Quantum Shield';
  }, []);

  // Calculate counts for each status
  const attackedCount = detectionResults.filter(result => result.status === 'attacked').length;
  const cleanCount = detectionResults.filter(result => result.status === 'clean').length;

  return (
    <div className="pt-20 min-h-screen">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-12">
          <h1 className="font-syncopate text-3xl md:text-4xl text-[#7dffe6] mb-4 gradient-text">
            Detection Dashboard
          </h1>
          <p className="text-[#b8f3fa]">
            Upload images to analyze and detect adversarial attacks. View results and statistics in real-time.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-[rgba(18,20,33,0.93)] p-6 md:p-8 rounded-2xl shadow-[0_8px_70px_rgba(0,255,248,0.33)] border border-[#25fff207] backdrop-blur-md transition-all duration-300 hover:shadow-[0_14px_88px_rgba(0,255,250,0.45)] hover:border-[#31ffe66e] h-full">
              <h2 className="font-syncopate text-xl text-[#7dffe6] mb-6">
                Upload Images for Analysis
              </h2>
              <ImageUploader />
            </div>
          </div>

          <div>
            <div className="bg-[rgba(18,20,33,0.93)] p-6 md:p-8 rounded-2xl shadow-[0_8px_70px_rgba(0,255,248,0.33)] border border-[#25fff207] backdrop-blur-md mb-8">
              <h2 className="font-syncopate text-xl text-[#7dffe6] mb-6 flex items-center">
                <BarChart3 className="mr-2 h-5 w-5" />
                Statistics
              </h2>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-[rgba(255,255,255,0.05)] rounded-lg">
                  <span className="text-[#94f1f1]">Total Analyzed:</span>
                  <span className="text-[#cafcff] font-semibold">{detectionResults.length}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-[rgba(255,255,255,0.05)] rounded-lg">
                  <div className="flex items-center">
                    <AlertCircle className="mr-2 h-4 w-4 text-[#ff4545]" />
                    <span className="text-[#ff4545]">Attacked:</span>
                  </div>
                  <span className="text-[#ff4545] font-semibold">{attackedCount}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-[rgba(255,255,255,0.05)] rounded-lg">
                  <div className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-[#19fd83]" />
                    <span className="text-[#19fd83]">Clean:</span>
                  </div>
                  <span className="text-[#19fd83] font-semibold">{cleanCount}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-[rgba(255,255,255,0.05)] rounded-lg">
                  <span className="text-[#94f1f1]">Model Accuracy:</span>
                  <span className="text-[#cafcff] font-semibold">91%</span>
                </div>
              </div>
            </div>

            {detectionResults.length > 0 && (
              <button
                onClick={clearResults}
                className="w-full bg-[rgba(255,77,77,0.1)] text-[#ff6b6b] border border-[#ff373730] rounded-xl py-3 px-4 flex items-center justify-center transition-all duration-300 hover:bg-[rgba(255,77,77,0.2)] hover:border-[#ff373760]"
              >
                <Trash2 className="mr-2 h-5 w-5" />
                Clear Results
              </button>
            )}
          </div>
        </div>

        {detectionResults.length > 0 && (
          <div className="mt-12">
            <h2 className="font-syncopate text-xl text-[#7dffe6] mb-6">
              Detection Results
            </h2>
            <div className="bg-[rgba(21,23,36,0.90)] rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full shadow-[0_8px_38px_rgba(16,255,248,0.11)]">
                  <thead>
                    <tr>
                      <th className="bg-gradient-to-r from-[#23243b] to-[#191928] text-[#18ffe2] p-4 font-syncopate uppercase tracking-wider text-left">
                        Image
                      </th>
                      <th className="bg-gradient-to-r from-[#23243b] to-[#191928] text-[#18ffe2] p-4 font-syncopate uppercase tracking-wider text-left">
                        Preview
                      </th>
                      <th className="bg-gradient-to-r from-[#23243b] to-[#191928] text-[#18ffe2] p-4 font-syncopate uppercase tracking-wider text-left">
                        Status
                      </th>
                      <th className="bg-gradient-to-r from-[#23243b] to-[#191928] text-[#18ffe2] p-4 font-syncopate uppercase tracking-wider text-left">
                        Confidence
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {detectionResults.map((result, index) => (
                      <tr 
                        key={index} 
                        className="border-b border-[#0bffe011] hover:bg-[#1e222e66] transition-colors"
                      >
                        <td className="p-4 text-[#cafcff]">{result.filename}</td>
                        <td className="p-4">
                          {result.imageUrl && (
                            <div className="h-16 w-16 rounded-md overflow-hidden border border-[#44fff730]">
                              <img 
                                src={result.imageUrl} 
                                alt={result.filename} 
                                className="h-full w-full object-cover"
                              />
                            </div>
                          )}
                        </td>
                        <td className="p-4">
                          <span 
                            className={`
                              font-medium text-sm uppercase tracking-wider py-1.5 px-4 rounded-full inline-block
                              ${result.status === 'attacked' 
                                ? 'text-[#ff4545] bg-[#361015aa] shadow-[0_0_17px_rgba(255,33,104,0.2)]' 
                                : 'text-[#19fd83] bg-[#173614a4] shadow-[0_0_17px_rgba(19,250,153,0.23)]'
                              }
                            `}
                          >
                            {result.status}
                          </span>
                        </td>
                        <td className="p-4 text-[#cafcff]">{result.confidence}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;