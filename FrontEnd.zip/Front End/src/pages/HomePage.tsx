import React, { useEffect } from 'react';
import Hero from '../components/Hero';
import FeaturesSection from '../components/FeaturesSection';
import ImageUploader from '../components/ImageUploader';
import StatsSection from '../components/StatsSection';
import ResultTable from '../components/ResultTable';

const HomePage: React.FC = () => {
  useEffect(() => {
    document.title = 'Quantum Shield - AI-Powered Adversarial Attack Detection';
  }, []);

  return (
    <div>
      <Hero />
      <FeaturesSection />
      
      <section className="py-20" id="upload">
        <div className="container mx-auto px-4">
          <h2 className="font-syncopate text-3xl md:text-4xl text-[#7dffe6] mb-12 cyberpunk-border gradient-text inline-block">
            Upload Your Image
          </h2>
          <div className="bg-[rgba(18,20,33,0.93)] p-8 md:p-12 rounded-3xl shadow-[0_8px_70px_rgba(0,255,248,0.33)] border border-[#25fff207] backdrop-blur-md transition-all duration-300 hover:shadow-[0_14px_88px_rgba(0,255,250,0.45)] hover:border-[#31ffe66e]">
            <ImageUploader />
          </div>
        </div>
      </section>
      
      <StatsSection />
      <ResultTable />
    </div>
  );
};

export default HomePage;