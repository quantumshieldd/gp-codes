import React, { useState, useEffect } from 'react';
import { Mail, Github, Linkedin } from 'lucide-react';

const AboutPage: React.FC = () => {
  useEffect(() => {
    document.title = 'About - Quantum Shield';
  }, []);

  // ✅ Contact Form State
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('sending');

    try {
      const res = await fetch(`${import.meta.env.VITE_API_URL}/contact`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, subject, message })
      });

      if (res.ok) {
        setStatus('sent');
        setName('');
        setEmail('');
        setSubject('');
        setMessage('');
      } else {
        setStatus('error');
      }
    } catch (err) {
      console.error(err);
      setStatus('error');
    }
  };

  return (
    <div className="pt-20 min-h-screen">
      <div className="container mx-auto px-4 py-8">
        {/* About + Mission + Tech */}
        <div className="mb-12">
          <h1 className="font-syncopate text-3xl md:text-4xl text-[#7dffe6] mb-4 gradient-text">
            About Quantum Shield
          </h1>
          <p className="text-[#b8f3fa] max-w-3xl">
            We're pioneering the integration of quantum computing and artificial intelligence 
            to create next-generation security solutions for autonomous vehicles and computer vision systems.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          <div className="lg:col-span-2">
            <div className="bg-[rgba(18,20,33,0.93)] p-8 rounded-2xl shadow-[0_8px_70px_rgba(0,255,248,0.33)] border border-[#25fff207] backdrop-blur-md">
              <h2 className="font-syncopate text-xl text-[#7dffe6] mb-6">Our Mission</h2>
              <p className="text-[#b8f3fa] mb-6">
                Quantum Shield leverages cutting-edge quantum-classical hybrid algorithms to detect adversarial attacks on computer vision systems.
                Our technology protects autonomous vehicles, security cameras, and other critical vision systems from sophisticated AI attacks.
              </p>
              <h2 className="font-syncopate text-xl text-[#7dffe6] mb-6 mt-10">The Technology</h2>
              <p className="text-[#b8f3fa] mb-4">
                Our system combines traditional convolutional neural networks with quantum computing elements to create a robust detection framework that can identify even the most subtle adversarial perturbations.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
                <div className="bg-[rgba(255,255,255,0.03)] p-6 rounded-xl border border-[#44fff715]">
                  <h3 className="text-[#44fff7] font-semibold mb-2">Classical CNN</h3>
                  <p className="text-[#87ffffbb] text-sm">Initial feature extraction and pre-processing using optimized convolutional layers</p>
                </div>
                <div className="bg-[rgba(255,255,255,0.03)] p-6 rounded-xl border border-[#44fff715]">
                  <h3 className="text-[#44fff7] font-semibold mb-2">Quantum Processing</h3>
                  <p className="text-[#87ffffbb] text-sm">Quantum circuits perform advanced pattern recognition for adversarial detection</p>
                </div>
                <div className="bg-[rgba(255,255,255,0.03)] p-6 rounded-xl border border-[#44fff715]">
                  <h3 className="text-[#44fff7] font-semibold mb-2">Hybrid Classifier</h3>
                  <p className="text-[#87ffffbb] text-sm">Combines quantum and classical outputs for high-accuracy classification</p>
                </div>
                <div className="bg-[rgba(255,255,255,0.03)] p-6 rounded-xl border border-[#44fff715]">
                  <h3 className="text-[#44fff7] font-semibold mb-2">Continuous Learning</h3>
                  <p className="text-[#87ffffbb] text-sm">System adapts to new attack vectors through continuous training pipeline</p>
                </div>
              </div>
            </div>
          </div>

          {/* Performance Metrics */}
          <div>
            <div className="bg-[rgba(18,20,33,0.93)] p-8 rounded-2xl shadow-[0_8px_70px_rgba(0,255,248,0.33)] border border-[#25fff207] backdrop-blur-md mb-8">
              <h2 className="font-syncopate text-xl text-[#7dffe6] mb-6">Performance Metrics</h2>
              <div className="space-y-6">
                {[
                  { label: 'Accuracy', value: '91%', width: '90%' },
                  { label: 'Precision', value: '91%', width: '92%' },
                  { label: 'Recall', value: '91%', width: '85%' },
                  { label: 'F1 Score', value: '91%', width: '89%' },
                ].map((item, i) => (
                  <div key={i}>
                    <div className="flex justify-between mb-2">
                      <span className="text-[#b8f3fa]">{item.label}</span>
                      <span className="text-[#44fff7] font-semibold">{item.value}</span>
                    </div>
                    <div className="h-2 bg-[rgba(255,255,255,0.05)] rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-[#31fad0] to-[#23a3fa] rounded-full" style={{ width: item.width }}></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

      {/* Meet the Team */}
<div className="mb-12">
  <h2 className="font-syncopate text-3xl md:text-4xl text-[#7dffe6] mb-8 cyberpunk-border gradient-text inline-block">
    Meet the Team
  </h2>

  {/* Supervisor - centered row */}
  <div className="flex justify-center mb-12">
    <div className="bg-[rgba(16,22,31,0.83)] p-8 rounded-xl text-center border border-[#26f3f40c] shadow-[0_2px_34px_rgba(20,255,241,0.24)] transition-all duration-300 hover:shadow-[0_8px_41px_rgba(0,255,255,0.56)] hover:border-[#28ffe9b5]">
      <div className="w-24 h-24 mx-auto rounded-full bg-[#1e2c3f] mb-6 overflow-hidden border-2 border-[#44fff7] shadow-lg">
        <img src="/images/mustafa1.jpg" alt="Dr. Mustafa Al-fayoumi" className="w-full h-full object-cover" />
      </div>
      <h3 className="font-syncopate text-[#36fad8] text-xl mb-2">Dr. Mustafa Al-fayoumi</h3>
      <p className="text-[#94f1f1] mb-4">Project Supervisor</p>
      <div className="flex justify-center space-x-4">
        <a href="mailto:m.alfayoumi@gmail.com" target="_blank"><Mail size={18} /></a>
        <a href="https://www.linkedin.com/in/mustafa-al-fayoumi-45b4501b/" target="_blank"><Linkedin size={18} /></a>
      </div>
    </div>
  </div>

  {/* Students - three in a row */}
  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
    {[
      {
        name: 'Maryam Abdulla',
        img: 'maryam1.png',
        email: 'mar20210615@std.psut.edu.jo',
        github: 'maryaamabdulla',
        linkedin: 'maryam-abdulla-29833b23b/',
      },
      {
        name: 'Bashar Hammad',
        img: 'bashar.png',
        email: 'bas20210878@std.psut.edu.jo',
        github: 'basharhammad4',
        linkedin: 'bashar-hammad-852644231/',
      },
      {
        name: 'Islam Abu Karaki',
        img: 'islam.jpg',
        email: 'isl20210627@std.psut.edu.jo',
        github: 'PrinceAK03',
        linkedin: 'islam-abukaraki-660b25249/',
      },
    ].map((person, i) => (
      <div key={i} className="bg-[rgba(16,22,31,0.83)] p-8 rounded-xl text-center border border-[#26f3f40c] shadow-[0_2px_34px_rgba(20,255,241,0.24)] transition-all duration-300 hover:shadow-[0_8px_41px_rgba(0,255,255,0.56)] hover:border-[#28ffe9b5]">
        <div className="w-24 h-24 mx-auto rounded-full bg-[#1e2c3f] mb-6 overflow-hidden border-2 border-[#44fff7] shadow-lg">
          <img src={`/images/${person.img}`} alt={person.name} className="w-full h-full object-cover" />
        </div>
        <h3 className="font-syncopate text-[#36fad8] text-xl mb-2">{person.name}</h3>
        <p className="text-[#94f1f1] mb-4">Cybersecurity Student</p>
        <div className="flex justify-center space-x-4">
          <a href={`mailto:${person.email}`} target="_blank"><Mail size={18} /></a>
          <a href={`https://github.com/${person.github}`} target="_blank"><Github size={18} /></a>
          <a href={`https://www.linkedin.com/in/${person.linkedin}`} target="_blank"><Linkedin size={18} /></a>
        </div>
      </div>
    ))}
  </div>
</div>

        {/* ✅ CONTACT US Section - FINAL FIXED */}
        <div>
          <h2 className="font-syncopate text-3xl md:text-4xl text-[#7dffe6] mb-8 cyberpunk-border gradient-text inline-block">Contact Us</h2>
          <div className="bg-[rgba(19,20,28,0.91)] p-8 rounded-3xl shadow-[0_8px_48px_rgba(0,255,234,0.1)] border border-[#12fce705]">
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="name" className="block text-[#cafcff] mb-2">Name</label>
                  <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} required className="w-full p-3 rounded-lg bg-[rgba(41,255,255,0.04)] text-[#fafcff]" placeholder="Your name" />
                </div>
                <div>
                  <label htmlFor="email" className="block text-[#cafcff] mb-2">Email</label>
                  <input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="w-full p-3 rounded-lg bg-[rgba(41,255,255,0.04)] text-[#fafcff]" placeholder="Your email" />
                </div>
              </div>
              <div className="mb-6">
                <label htmlFor="subject" className="block text-[#cafcff] mb-2">Subject</label>
                <input type="text" id="subject" value={subject} onChange={(e) => setSubject(e.target.value)} required className="w-full p-3 rounded-lg bg-[rgba(41,255,255,0.04)] text-[#fafcff]" placeholder="Subject" />
              </div>
              <div className="mb-6">
                <label htmlFor="message" className="block text-[#cafcff] mb-2">Message</label>
                <textarea id="message" rows={6} value={message} onChange={(e) => setMessage(e.target.value)} required className="w-full p-3 rounded-lg bg-[rgba(41,255,255,0.04)] text-[#fafcff]" placeholder="Your message"></textarea>
              </div>
              <button type="submit" disabled={status === 'sending'} className="bg-gradient-to-r from-[#31fad0] via-[#23a3fa] to-[#383872] px-8 py-4 rounded-xl font-semibold uppercase tracking-wider text-white">
                {status === 'sending' ? 'Sending...' : 'Send Message'}
              </button>
              {status === 'sent' && <p className="mt-4 text-green-400 font-medium">✅ Message sent successfully!</p>}
              {status === 'error' && <p className="mt-4 text-red-400 font-medium">❌ Failed to send message. Please try again.</p>}
            </form>
          </div>
        </div>

      </div>
    </div>
  );
};

export default AboutPage;
