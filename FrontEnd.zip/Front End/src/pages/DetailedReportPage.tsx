import React, { useEffect, useState } from 'react';
import { useImageProcessing } from '../context/ImageProcessingContext';
import { BarChart, Filter, Download, Rows } from 'lucide-react';
import autoTable from 'jspdf-autotable';
import { jsPDF } from 'jspdf';

const DetailedReportPage: React.FC = () => {
  const { detectionResults, stats } = useImageProcessing();
  const [filter, setFilter] = useState<'all' | 'attacked' | 'clean'>('all');
  const [view, setView] = useState<'list' | 'grid'>('grid');

  useEffect(() => {
    document.title = 'Detailed Report - Quantum Shield';
  }, []);

  const filteredResults = detectionResults.filter(result => {
    if (filter === 'all') return true;
    return result.status === filter;
  });

  const attackedPercentage = detectionResults.length
    ? (detectionResults.filter(r => r.status === 'attacked').length / detectionResults.length) * 100
    : 0;

  const cleanPercentage = 100 - attackedPercentage;

  const exportToCSV = () => {
    const csvRows = [
      ['#', 'Filename', 'Status', 'Confidence']
    ];

    detectionResults.forEach((result, index) => {
      csvRows.push([
        (index + 1).toString(),
        result.filename,
        result.status.toUpperCase(),
        `${result.confidence.toFixed(1)}%`
      ]);
    });

    const csvContent = csvRows.map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = 'Quantum_Shield_Report.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportToPDF = () => {
    const doc = new jsPDF({ orientation: 'portrait', unit: 'px', format: 'a4' });

    doc.setFillColor(18, 20, 33); // dark background like site
    doc.rect(0, 0, doc.internal.pageSize.getWidth(), doc.internal.pageSize.getHeight(), 'F');

    doc.setTextColor(125, 255, 230); // neon blue text
    doc.setFontSize(20);
    doc.text('Quantum Shield Detection Report', 40, 50);

    const tableData = detectionResults.map((result, index) => [
      index + 1,
      result.filename,
      result.status.toUpperCase(),
      `${result.confidence.toFixed(1)}%`
    ]);

    autoTable(doc, {
      head: [['#', 'Filename', 'Status', 'Confidence']],
      body: tableData,
      startY: 70,
      theme: 'grid',
      headStyles: {
        fillColor: [0, 255, 248],
        textColor: [18, 20, 33],
        fontStyle: 'bold',
        fontSize: 12,
      },
      styles: {
        fillColor: [28, 30, 48],
        textColor: [200, 255, 255],
        halign: 'center',
        valign: 'middle',
        fontSize: 10,
        cellPadding: 4,
      },
      alternateRowStyles: {
        fillColor: [24, 26, 42]
      },
      margin: { left: 40, right: 40 }
    });

    doc.save('Quantum_Shield_Report.pdf');
  };

  return (
    <div className="pt-20 min-h-screen">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-12">
          <h1 className="font-syncopate text-3xl md:text-4xl text-[#7dffe6] mb-4 gradient-text">
            Detailed Detection Report
          </h1>
          <p className="text-[#b8f3fa]">Comprehensive analysis of all processed images with detailed metrics and insights.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* Detection Overview */}
          <div className="bg-[rgba(18,20,33,0.93)] p-6 rounded-2xl border border-[#25fff207] backdrop-blur-md">
            <h2 className="font-syncopate text-xl text-[#7dffe6] mb-6 flex items-center">
              <BarChart className="mr-2 h-5 w-5" />
              Detection Overview
            </h2>

            {detectionResults.length > 0 ? (
              <>
                <div className="relative h-6 bg-[rgba(255,255,255,0.05)] rounded-full overflow-hidden mb-4">
                  <div className="absolute top-0 left-0 h-full bg-[#ff4545]" style={{ width: `${attackedPercentage}%` }} />
                  <div className="absolute top-0 right-0 h-full bg-[#19fd83]" style={{ width: `${cleanPercentage}%` }} />
                </div>

                <div className="flex justify-between mb-6">
                  <span className="text-[#ff4545] text-sm">Attacked ({Math.round(attackedPercentage)}%)</span>
                  <span className="text-[#19fd83] text-sm">Clean ({Math.round(cleanPercentage)}%)</span>
                </div>
              </>
            ) : <p className="text-[#87ffffbb] text-center py-4">No data available yet</p>}

            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-[rgba(255,255,255,0.05)] rounded-lg">
                <span className="text-[#94f1f1]">Images Analyzed:</span>
                <span className="text-[#cafcff] font-semibold">{detectionResults.length}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-[rgba(255,255,255,0.05)] rounded-lg">
                <span className="text-[#94f1f1]">Avg. Confidence:</span>
                <span className="text-[#cafcff] font-semibold">
                  {detectionResults.length 
                    ? `${(detectionResults.reduce((acc, r) => acc + r.confidence, 0) / detectionResults.length).toFixed(1)}%`
                    : 'N/A'}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-[rgba(255,255,255,0.05)] rounded-lg">
                <span className="text-[#94f1f1]">Model Accuracy:</span>
                <span className="text-[#cafcff] font-semibold">91%</span>
              </div>
            </div>
          </div>

          {/* Detection Results */}
          <div className="lg:col-span-2">
            <div className="bg-[rgba(18,20,33,0.93)] p-6 rounded-2xl border border-[#25fff207] backdrop-blur-md h-full">
              <div className="flex flex-wrap items-center justify-between mb-6">
                <h2 className="font-syncopate text-xl text-[#7dffe6] mb-2 md:mb-0 flex items-center">
                  <Filter className="mr-2 h-5 w-5" />
                  Detection Results
                </h2>

                <div className="flex space-x-2">
                  <div className="flex bg-[rgba(255,255,255,0.05)] rounded-lg overflow-hidden">
                    {['all', 'attacked', 'clean'].map(f => (
                      <button key={f} className={`px-3 py-1.5 text-sm ${filter === f ? 'bg-[#43fff015] text-[#43fff0]' : 'text-[#94f1f1]'}`} onClick={() => setFilter(f as any)}>
                        {f[0].toUpperCase() + f.slice(1)}
                      </button>
                    ))}
                  </div>
                  <div className="flex bg-[rgba(255,255,255,0.05)] rounded-lg overflow-hidden">
                    <button className={`px-3 py-1.5 ${view === 'grid' ? 'bg-[#43fff015] text-[#43fff0]' : 'text-[#94f1f1]'}`} onClick={() => setView('grid')}>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" stroke="currentColor"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                    </button>
                    <button className={`px-3 py-1.5 ${view === 'list' ? 'bg-[#43fff015] text-[#43fff0]' : 'text-[#94f1f1]'}`} onClick={() => setView('list')}>
                      <Rows size={16} />
                    </button>
                  </div>
                </div>
              </div>

              {detectionResults.length > 0 ? (
                view === 'grid' ? (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {filteredResults.map((r, i) => (
                      <div key={i} className="bg-[rgba(21,23,36,0.90)] rounded-lg overflow-hidden border border-[#44fff730]">
                        <div className="aspect-square relative">
                          <img src={r.imageUrl} alt={r.filename} className="w-full h-full object-cover" />
                          <div className={`absolute top-2 right-2 text-xs py-1 px-2 rounded-full ${r.status === 'attacked' ? 'text-[#ff4545] bg-[#36101599]' : 'text-[#19fd83] bg-[#17361499]'}`}>
                            {r.status}
                          </div>
                        </div>
                        <div className="p-3">
                          <p className="text-[#cafcff] text-sm truncate">{r.filename}</p>
                          <div className="flex justify-between items-center mt-1">
                            <span className="text-[#87ffffbb] text-xs">Confidence:</span>
                            <span className="text-[#43fff0] text-xs font-semibold">{r.confidence}%</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr>
                          <th className="text-left p-3 text-[#18ffe2] text-sm">Filename</th>
                          <th className="text-left p-3 text-[#18ffe2] text-sm">Status</th>
                          <th className="text-left p-3 text-[#18ffe2] text-sm">Confidence</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredResults.map((r, i) => (
                          <tr key={i} className="border-b border-[#0bffe011] hover:bg-[#1e222e66]">
                            <td className="p-3 flex items-center">
                              <div className="h-10 w-10 rounded-md overflow-hidden border border-[#44fff730] mr-3">
                                <img src={r.imageUrl} alt={r.filename} className="h-full w-full object-cover" />
                              </div>
                              <span className="text-[#cafcff] text-sm">{r.filename}</span>
                            </td>
                            <td className="p-3">
                              <span className={`text-xs py-1 px-2 rounded-full ${r.status === 'attacked' ? 'text-[#ff4545] bg-[#36101599]' : 'text-[#19fd83] bg-[#17361499]'}`}>
                                {r.status}
                              </span>
                            </td>
                            <td className="p-3 text-[#cafcff]">{r.confidence}%</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )
              ) : (
                <div className="bg-[rgba(21,23,36,0.90)] rounded-lg p-8 text-center text-[#87ffffbb]">
                  No detection results yet. Upload images to see results here.
                </div>
              )}

              {detectionResults.length > 0 && (
                <div className="mt-6 flex justify-end space-x-3">
                  <button onClick={exportToCSV} className="flex items-center bg-[rgba(46,255,225,0.07)] text-[#43fff0] px-4 py-2 rounded-lg hover:bg-[rgba(46,255,225,0.15)] transition">
                    <Download className="mr-2 h-4 w-4" />
                    Export CSV
                  </button>
                  <button onClick={exportToPDF} className="flex items-center bg-[rgba(46,255,225,0.07)] text-[#43fff0] px-4 py-2 rounded-lg hover:bg-[rgba(46,255,225,0.15)] transition">
                    <Download className="mr-2 h-4 w-4" />
                    Export PDF
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DetailedReportPage;
