export async function analyzeImage(file: File) {
  const formData = new FormData();
  formData.append("file", file); // ✅ FIXED

  console.log("📤 Sending to:", import.meta.env.VITE_API_URL);

  const response = await fetch(`${import.meta.env.VITE_API_URL}/predict`, {
    method: "POST",
    body: formData,
  });

  if (!response.ok) {
    throw new Error("API error");
  }

  return response.json(); // expected: { prediction, confidence }
}
