import React, { createContext, useContext, useState } from 'react';

interface DetectionResult {
  id: string;
  filename: string;
  imageUrl: string;
  status: 'clean' | 'attacked';
  confidence: number;
}

interface Stats {
  totalImages: number;
  attacksDetected: number;
  accuracy: number;
}

type ProcessingStatus = 'idle' | 'processing' | 'completed' | 'error';

interface ImageProcessingContextType {
  detectionResults: DetectionResult[];
  processingStatus: ProcessingStatus;
  stats: Stats;
  clearResults: () => void;
  addDetectionResult: (result: DetectionResult) => void;
  updateStats: (status: 'clean' | 'attacked') => void;
  setProcessingStatus: (status: ProcessingStatus) => void;
}

const ImageProcessingContext = createContext<ImageProcessingContextType | undefined>(undefined);

export const useImageProcessing = () => {
  const context = useContext(ImageProcessingContext);
  if (context === undefined) {
    throw new Error('useImageProcessing must be used within an ImageProcessingProvider');
  }
  return context;
};

export const ImageProcessingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [detectionResults, setDetectionResults] = useState<DetectionResult[]>([]);
  const [processingStatus, setProcessingStatus] = useState<ProcessingStatus>('idle');
  const [stats, setStats] = useState<Stats>({
    totalImages: 0,
    attacksDetected: 0,
    accuracy: 91 // Static
  });

  const addDetectionResult = (result: DetectionResult) => {
    setDetectionResults((prev) => [...prev, result]);
    updateStats(result.status);
  };

  const updateStats = (status: 'clean' | 'attacked') => {
    setStats((prev) => ({
      totalImages: prev.totalImages + 1,
      attacksDetected: prev.attacksDetected + (status === 'attacked' ? 1 : 0),
      accuracy: prev.accuracy
    }));
  };

  const clearResults = () => {
    detectionResults.forEach((r) => URL.revokeObjectURL(r.imageUrl));
    setDetectionResults([]);
    setStats({ totalImages: 0, attacksDetected: 0, accuracy: 91 });
    setProcessingStatus('idle');
  };

  return (
    <ImageProcessingContext.Provider
      value={{
        detectionResults,
        processingStatus,
        stats,
        clearResults,
        addDetectionResult,
        updateStats,
        setProcessingStatus,
      }}
    >
      {children}
    </ImageProcessingContext.Provider>
  );
};
