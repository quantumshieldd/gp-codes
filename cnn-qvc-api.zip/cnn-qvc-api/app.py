from flask import Flask, request, jsonify
from PIL import Image
import numpy as np
from model import build_model
import tensorflow as tf
from flask_cors import CORS
import smtplib
from email.mime.text import MIMEText

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Load the model
print("Loading model...")
model = build_model()
model.load_weights("maryam12_finetuned_weights.h5")  
model.compile(optimizer=tf.keras.optimizers.Adam(), loss=tf.keras.losses.BinaryCrossentropy(), metrics=["accuracy"])
print("Model loaded successfully!")

# Define allowed image extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def preprocess_image(image):
    image = image.convert('RGB')  # Always ensure RGB
    image = image.resize((512, 256))  # Resize to model input
    image = np.array(image) / 255.0
    image = np.expand_dims(image, axis=0)
    return image

@app.route('/predict', methods=['POST'])
def predict():
    print("\n /predict was hit")

    if 'file' not in request.files:
        print(" No file key in request.files")
        return jsonify({"error": "No file provided"}), 400

    file = request.files['file']
    print("Received file:", file.filename)
    print(" MIME type:", file.content_type)

    file_bytes = file.read()
    print("File size (bytes):", len(file_bytes))

    if len(file_bytes) < 1000:
        return jsonify({"error": "Uploaded file is too small or corrupted"}), 400

    file.seek(0)

    if not allowed_file(file.filename):
        return jsonify({"error": "Invalid file type. Only PNG, JPG, and JPEG are allowed."}), 400

    try:
        image = Image.open(file)
        print("🖼 Image mode before conversion:", image.mode)

        image = image.convert("RGB")
        print("Image mode after conversion:", image.mode)

        image = image.resize((512, 256))
        print(" Image resized to:", image.size)

        image = np.array(image)
        print(" Image array shape:", image.shape)
        print(" Pixel range: min =", np.min(image), ", max =", np.max(image))

        image = image / 255.0
        image = np.expand_dims(image, axis=0)
        print(" Final input shape:", image.shape)

        prediction = model.predict(image, verbose=0)[0][0]
        
        label = "Adversarial" if prediction > 0.5 else "Clean"
        confidence = float(prediction) if label == "Adversarial" else float(1-prediction)

        print(" Prediction:", label, "| Confidence:", confidence)

        return jsonify({
            "prediction": label,
            "confidence": confidence
        })

    except Exception as e:
        print(" Exception during processing:", str(e))
        return jsonify({"error": str(e)}), 500
GMAIL_USER = "quantumshieldd@gmail.com"
GMAIL_APP_PASSWORD = "gsmj knxq mluc ufvw"

@app.route('/contact', methods=['POST'])
def contact():
    data = request.get_json()

    name = data.get("name")
    email = data.get("email")
    subject = data.get("subject")
    message = data.get("message")

    if not all([name, email, subject, message]):
        return jsonify({"error": "All fields are required"}), 400

    # Build the email content
    body = f"""
    New contact form submission from Quantum Shield:

    Name: {name}
    Email: {email}
    Subject: {subject}

    Message:
    {message}
    """

    try:
        msg = MIMEText(body)
        msg["Subject"] = f"[QuantumShield Contact] {subject}"
        msg["From"] = GMAIL_USER
        msg["To"] = GMAIL_USER

        server = smtplib.SMTP_SSL("smtp.gmail.com", 465)
        server.login(GMAIL_USER, GMAIL_APP_PASSWORD)
        server.send_message(msg)
        server.quit()

        return jsonify({"message": "Message sent successfully!"}), 200

    except Exception as e:
        print(" Email failed:", str(e))
        return jsonify({"error": "Failed to send message."}), 500

@app.route('/', methods=['GET'])
def health_check():
    return "API is running!"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000,debug=True)