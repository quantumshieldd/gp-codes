import tensorflow as tf
from tensorflow.keras import layers
import pennylane as qml
from pennylane.qnn import KerasLayer

# Quantum Circuit
n_qubits = 6
dev = qml.device("default.qubit", wires=n_qubits)

@qml.qnode(dev, interface="tf")
def quantum_circuit(inputs, weights):
    qml.templates.AngleEmbedding(inputs, wires=range(n_qubits), rotation="Y")
    qml.templates.StronglyEntanglingLayers(weights, wires=range(n_qubits))
    return [qml.expval(qml.PauliZ(i)) for i in range(n_qubits)]

# Create the quantum layer
weight_shapes = {"weights": (3, n_qubits, 3)}
q_layer = KerasLayer(quantum_circuit, weight_shapes, output_dim=n_qubits)

def build_model():
    model = tf.keras.Sequential([
        layers.Input(shape=(256, 512, 3)),
        layers.Conv2D(32, (3, 3), activation="relu"),
        layers.MaxPooling2D(),
        layers.BatchNormalization(),
        layers.Conv2D(64, (3, 3), activation="relu"),
        layers.MaxPooling2D(),
        layers.BatchNormalization(),
        layers.GlobalAveragePooling2D(),
        layers.Dense(64, activation="relu"),
        layers.Dropout(0.3),
        layers.Dense(n_qubits, activation="tanh"),
        q_layer,
        layers.Dense(1, activation="sigmoid")
    ])
    return model